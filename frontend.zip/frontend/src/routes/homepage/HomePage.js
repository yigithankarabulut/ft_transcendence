import { navigateTo } from "../../utils/navTo.js";
import { toggleHidden,  insertIntoElement } from "../../utils/utils.js";

const userDetailUrl = "http://127.0.0.1:8000/user/home";
document.getElementById('nav-bar').style.display = 'flex';
export async function fetchUserDetails() {

 console.log("fetchUserDetails")

}
